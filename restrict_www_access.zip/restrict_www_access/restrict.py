import frappe

def block_desk_on_www():
    host = frappe.get_request_header("host") or ""
    path = frappe.local.request.path or ""

    if host == "www.cmbakers.co.zm" and (
        path.startswith("/app") or path.startswith("/login") or path.startswith("/desk")
    ):
        frappe.local.response["type"] = "redirect"
        frappe.local.response["location"] = "/"
        raise frappe.Redirect
