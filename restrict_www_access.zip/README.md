# restrict_www_access
Restrict public access to desk or any core app. Public visitors will only see website app on main domain.