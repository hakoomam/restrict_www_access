# restrict_www_access/hooks.py

before_request = "restrict_www_access.restrict.block_desk_on_www"
